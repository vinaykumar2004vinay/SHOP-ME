package com.ecommerce.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * CheckoutRequest DTO — collects all info needed to place an order.
 * Submitted by user at the final checkout step.
 */
@Data
public class CheckoutRequest {

    @NotNull(message = "User ID is required")
    private Long userId;

    @NotBlank(message = "Shipping address is required")
    private String shippingAddress;

    @NotBlank(message = "Payment method is required")
    private String paymentMethod; // e.g., "CREDIT_CARD", "DEBIT_CARD", "UPI", "COD"

    @NotBlank(message = "Delivery option is required")
    private String deliveryOption; // e.g., "STANDARD", "EXPRESS", "OVERNIGHT"
}
