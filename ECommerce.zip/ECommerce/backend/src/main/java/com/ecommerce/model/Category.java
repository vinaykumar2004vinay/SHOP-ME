package com.ecommerce.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.util.List;

/**
 * Category entity — groups products for easy browsing.
 *
 * WHY @JsonIgnore on products: Category has a bidirectional relationship with
 * Product. Without @JsonIgnore, Jackson serializes Category → products list →
 * each Product → its category → products list again → INFINITE LOOP. This
 * causes StackOverflowError and a 500 on GET /api/categories.
 *
 * WHY @Getter/@Setter instead of @Data:
 *
 * @Data generates equals/hashCode using ALL fields including lazy collections,
 * which causes LazyInitializationException when Hibernate tries to compare
 * detached entities. @Getter/@Setter is safe.
 */
@Entity
@Table(name = "categories")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Category name must be unique — no duplicate Electronics
    @Column(nullable = false, unique = true, length = 100)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    // Icon/emoji for visual display in frontend category chips
    @Column(length = 50)
    private String icon;

    /**
     * @JsonIgnore — breaks Category → Product → Category infinite loop. The
     * products list is never needed when serializing a category to JSON.
     * Products carry their category info (name/id), not the other way.
     */
    @JsonIgnore
    @OneToMany(mappedBy = "category", fetch = FetchType.LAZY)
    private List<Product> products;
}
