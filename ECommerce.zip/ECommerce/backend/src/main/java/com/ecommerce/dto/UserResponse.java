package com.ecommerce.dto;

import com.ecommerce.model.User;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * UserResponse DTO — safe user data returned to frontend.
 * Password is intentionally excluded — never send passwords in responses.
 */
@Data
@NoArgsConstructor
public class UserResponse {

    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String shippingAddress;
    private String role;
    private LocalDateTime createdAt;
    private Boolean isActive;

    // Constructor from User entity — maps only safe fields
    public UserResponse(User user) {
        this.id = user.getId();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.email = user.getEmail();
        this.shippingAddress = user.getShippingAddress();
        this.role = user.getRole().name();
        this.createdAt = user.getCreatedAt();
        this.isActive = user.getIsActive();
    }
}
