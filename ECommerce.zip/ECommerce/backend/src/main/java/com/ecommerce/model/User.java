package com.ecommerce.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * User entity — maps to 'users' table via Hibernate auto DDL.
 *
 * WHY @JsonIgnore on orders and cart: User ↔ Order is bidirectional. Without
 * @JsonIgnore: User → orders → each Order → user → orders → ... INFINITE LOOP
 * User ↔ Cart is bidirectional. Without @JsonIgnore: User → cart → user → cart
 * → ... INFINITE LOOP Both collections are ignored on the User side — the
 * frontend never needs full order history embedded inside a user object. Orders
 * are fetched separately via /api/orders/user/{id}.
 */
@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "first_name", nullable = false, length = 50)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 50)
    private String lastName;

    // Email is used as the login identifier — must be unique
    @Column(nullable = false, unique = true, length = 100)
    private String email;

    // Password stored as plain text (no security required per spec)
    @Column(nullable = false)
    private String password;

    // Full shipping address in one field for simplicity
    @Column(name = "shipping_address", columnDefinition = "TEXT")
    private String shippingAddress;

    // Role determines access level: CUSTOMER or ADMIN
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private User.Role role = User.Role.CUSTOMER;

    // Timestamp when account was created — uses Java 8 LocalDateTime
    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    // Soft-delete: deactivated accounts remain in DB for order history
    @Column(name = "is_active")
    private Boolean isActive = true;

    /**
     * @JsonIgnore — prevents User → orders → user → ... infinite loop. Orders
     * are loaded separately; they don't need to be embedded in User JSON.
     */
    @JsonIgnore
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Order> orders = new ArrayList<>();

    /**
     * @JsonIgnore — prevents User → cart → user → ... infinite loop. Cart is
     * fetched directly via /api/cart/{userId}, not through User.
     */
    @JsonIgnore
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private Cart cart;

    public enum Role {
        CUSTOMER, ADMIN
    }
}
