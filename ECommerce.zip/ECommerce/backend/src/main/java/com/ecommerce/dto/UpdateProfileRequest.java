package com.ecommerce.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * UpdateProfileRequest — used for PUT /api/users/{id} (profile update).
 *
 * WHY a separate DTO from RegisterRequest:
 *   RegisterRequest has @NotBlank on password — mandatory during registration.
 *   But when updating a profile the user may not want to change their password,
 *   so the password field should be optional (null = keep existing password).
 *   Reusing RegisterRequest caused: "Validation failed: {password=Password is required}"
 *   whenever the frontend sent a profile update without a new password.
 *
 *   Solution: split into two DTOs with different validation rules.
 *   - RegisterRequest  → password @NotBlank  (registration — password always required)
 *   - UpdateProfileRequest → password @Size only, nullable (update — password optional)
 */
@Data
public class UpdateProfileRequest {

    @NotBlank(message = "First name is required")
    @Size(max = 50, message = "First name must be under 50 characters")
    private String firstName;

    @NotBlank(message = "Last name is required")
    @Size(max = 50, message = "Last name must be under 50 characters")
    private String lastName;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    /**
     * Password is OPTIONAL on update.
     * If null or blank → keep existing password unchanged.
     * If provided      → must be at least 6 characters.
     */
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;

    @NotBlank(message = "Shipping address is required")
    private String shippingAddress;
}
