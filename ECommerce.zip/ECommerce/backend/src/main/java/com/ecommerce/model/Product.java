package com.ecommerce.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Product entity — core catalog item with price, stock, and category.
 *
 * WHY @JsonIgnoreProperties on category: Product → category → products (list) →
 * product → category → ... Category.products is already @JsonIgnored, but using
 *
 * @JsonIgnoreProperties here too gives defense-in-depth and makes the intent
 * explicit: when serializing the category inside a product, skip its products
 * list and any other potentially recursive fields.
 */
@Entity
@Table(name = "products")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    // BigDecimal for precise monetary calculations — avoids float rounding
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    // Stock quantity — decremented on order, incremented on cancellation
    @Column(nullable = false)
    private Integer quantity;

    // Comma-separated or single image URL
    @Column(name = "image_url", columnDefinition = "TEXT")
    private String imageUrl;

    /**
     * @JsonIgnoreProperties — serialize category name/id/icon with the product
     * (frontend needs it for display), but skip category's 'products' list to
     * prevent Product → Category → Product → ... infinite loop.
     */
    @JsonIgnoreProperties({"products", "hibernateLazyInitializer", "handler"})
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "category_id")
    private Category category;

    @Column(name = "is_active")
    private Boolean isActive = true;

    // Java 8 LocalDateTime — when product was added
    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();
}
